package com.example.order5;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<Item> mylst = new ArrayList<>();
    Button btn, bta;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.rv);// Связь разметки с кодом
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        setInitialData();

        ArrayAdapter adapter = new ArrayAdapter(this, mylst);
        recyclerView.setAdapter(adapter);

    }
    public void setInitialData() {
        mylst.add(new Item((R.drawable.beefsteak_1), "Бифштекс", 4, 230, 2, false));
        mylst.add(new Item((R.drawable.duck), "Утка", 2, 270, 1, false));
        mylst.add(new Item((R.drawable.fruit), "Фрукты", 3, 30, 3, false));
        mylst.add(new Item((R.drawable.icecream), "Мороженое", 5, 70, 5, false));
        mylst.add(new Item((R.drawable.pizza), "Пицца", 4, 230, 4, false));
    }
}
