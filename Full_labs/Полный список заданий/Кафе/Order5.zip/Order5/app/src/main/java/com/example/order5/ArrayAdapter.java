package com.example.order5;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ArrayAdapter extends RecyclerView.Adapter<ArrayAdapter.ViewHolder> implements View.OnClickListener {
    private final LayoutInflater inflater;
    private final ArrayList<Item> mylst;
    private ItemClickListener mClickListener;

    public ArrayAdapter(Context context, ArrayList<Item> mylst) {
        this.inflater = LayoutInflater.from(context);
        this.mylst = mylst;
    }
    // Обработка от BindViewHolder
    @Override
    public void onClick(View v) {
        switch (v.getId()) {// Выбранная кнопка
            case R.id.btm:      //

                break;
            case R.id.btp://

                break;
        }
    }
    // Родительская activity будет вызывать этот метод в ответ на    // событие щелчка.
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }
    @NonNull
    @Override
    public ArrayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_list, parent, false);
        return new ViewHolder(view);
    }
    int pos;
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ArrayAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        pos = position; // pos объявлена глобально для обработки списка в адаптере
        Item it = mylst.get(position);
        holder.imgView.setImageResource(it.getImg());
        holder.txtName.setText(it.getName());
        holder.txtResp.setText("Рейтинг "+String.valueOf(it.getResp()));
        holder.txtPrice.setText("Цена "+String.valueOf(it.getPrice()));
        holder.txtQuan.setText(String.valueOf(it.getQuan()));
        holder.btm.setOnClickListener(this);
        holder.btp.setOnClickListener(this);
    }

    @Override
    public int getItemCount() {
        return mylst.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgView;
        TextView txtName, txtResp, txtPrice, txtQuan, btm, btp, btn ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgView = itemView.findViewById(R.id.imgView);
            txtName = itemView.findViewById(R.id.textName);
            txtResp = itemView.findViewById(R.id.txtResp);
            txtPrice = itemView.findViewById(R.id.textPrice);
            txtQuan = itemView.findViewById(R.id.txtQuan);
            btm = itemView.findViewById(R.id.btm);
            btp = itemView.findViewById(R.id.btp);
            btn = itemView.findViewById(R.id.btnext);
            btn.setOnClickListener(this);

        }
        // Обработка щелчков от ViewHolder
        @Override
        public void onClick(View v) {
//            int [] lin = new int[]
            int num = 0;// Значение num
            Item it = mylst.get(pos);
            switch (v.getId()) {// Выбранная кнопка
                case R.id.btm:      // Уменьшить количество
                    if(it.quan > 0) it.quan--;
                    break;
                case R.id.btp:      // Увеличить количество
                    it.quan++;
                case R.id.btnext: // Переход на следующую страницу

//                    Context context = v.getContext();
//                    Intent intent = new Intent(context, ShowList.class);
//                    context.startActivity(intent);
                    break;
//                case R.id.reset://
//
//                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + v.getId());
            }

//            showVisual(res);// Показать итог
        }

    }

//        @Override
//        public void onClick(View v) {
//            if (mClickListener != null) mClickListener.onItemClick(v, getAdapterPosition());
//        }

}

//           Toast.makeText(v.getContext(), "ITEM PRESSED = +",
//           Toast.LENGTH_SHORT).show();
//            if (v.getId() == btm.getId()){
//                    if(q > 0) q--;
//                    }
//                    if(v.getId() == btp.getId()){
//                    q++;
//                    }
//                    String num= Integer.toString(q);
//                    txtQuan.setText(num);
//                    it.quan=q;
//                    }
