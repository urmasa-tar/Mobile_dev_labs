package com.example.cards_4;

import android.content.ClipData;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyCardAdapter extends RecyclerView.Adapter<MyCardAdapter.MyViewHolder>implements View.OnClickListener
{
    ArrayList<Person> people;

    public MyCardAdapter(ArrayList<Person> people) {
        this.people = people;
    }

    @Override
    public void onClick(View view) {

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_list, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        ImageView imageView = holder.imgView;
        TextView tvname = holder.tvname;
        TextView tvtitle = holder.tvtitle;
//        str = String.valueOf(position);
        imageView.setImageResource(people.get(position).getImg());
        tvname.setText(people.get(position).getRef());
        tvtitle.setText(people.get(position).getTitle());
        holder.itemView.setOnClickListener(this::onClick);
    }

    @Override
    public int getItemCount() {
        return people.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView imgView;
        TextView tvname;
        TextView tvtitle;
        public View view;
        public ClipData.Item currentItem;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.imgView = (ImageView) itemView.findViewById(R.id.imgView);
            this.tvname = (TextView) itemView.findViewById(R.id.tvname);
            this.tvtitle = (TextView) itemView.findViewById(R.id.tvtitle);
        }
    }
}
