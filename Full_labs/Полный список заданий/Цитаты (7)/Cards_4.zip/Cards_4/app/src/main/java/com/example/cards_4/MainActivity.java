package com.example.cards_4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Person> people;
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private static RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView = (RecyclerView) findViewById(R.id.recv);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setItemAnimator(new DefaultItemAnimator());

        people = new ArrayList<Person>();
        for (int i = 0; i < 5; i++) {
            people.add(new Person(
                    MyData.drawableArray[i],
                    MyData.nameArray[i],
                    MyData.titleArray[i])     );
        }

        adapter = new MyCardAdapter(people);
        recyclerView.setAdapter(adapter);

//        recyclerView.setOnClickListener(this);

    }
}