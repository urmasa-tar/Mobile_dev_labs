package com.example.cards_4;

public class MyData {
    public MyData() {
    }

    static int[] drawableArray = {R.drawable.chekhov, R.drawable.filatov, R.drawable.m_zadornov, R.drawable.matroskin_2, R.drawable.pes};

    static String[] nameArray = {"Чехов", "Филатов", "Задорнов", "Матроскин", "Пес", "Ржевский"};
    static String[] titleArray = {"Писатель", "Актер", "Сатирик", "Кот из Простоквашино", "Народный юмор"};
}