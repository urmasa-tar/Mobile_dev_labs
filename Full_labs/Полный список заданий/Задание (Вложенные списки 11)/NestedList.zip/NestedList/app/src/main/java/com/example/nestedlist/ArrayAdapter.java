package com.example.nestedlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.zip.Inflater;

public class ArrayAdapter extends RecyclerView.Adapter<ArrayAdapter.ViewHolder>{
    private final LayoutInflater inflater;
    private final ArrayList<Cell> mylst;
    private ItemClickListener mClickListener;

    public ArrayAdapter(Context context, ArrayList<Cell> mylst) {
        this.inflater = LayoutInflater.from(context);
        this.mylst = mylst;
    }

    // Родительская activity будет вызывать этот метод в ответ на    // событие щелчка.
    public interface ItemClickListener {
        void onItemClick(View view, int position);
    }

    void setClickListener(ItemClickListener itemClickListener) {
        this.mClickListener = itemClickListener;
    }
    @NonNull
    @Override
    public ArrayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArrayAdapter.ViewHolder holder, int position) {
        Cell cl = mylst.get(position);
        holder.imgView.setImageDrawable(cl.getPic());
        holder.txtView.setText(cl.getStr());
    }

    @Override
    public int getItemCount() {
        return mylst.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgView;
        TextView txtView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgView = itemView.findViewById(R.id.imgView);
            txtView = itemView.findViewById(R.id.txtView);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (mClickListener != null) mClickListener.onItemClick(v, getAdapterPosition());
        }
    }
}

