package com.example.nestedlist;

import android.graphics.drawable.Drawable;

public class Cell {
    Drawable pic;
    String str;

    public Cell(Drawable pic, String str) {
        this.pic = pic;
        this.str = str;
    }



    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    public Drawable getPic() {
        return pic;
    }

    public void setPic(Drawable pic) {
        this.pic = pic;
    }
}
