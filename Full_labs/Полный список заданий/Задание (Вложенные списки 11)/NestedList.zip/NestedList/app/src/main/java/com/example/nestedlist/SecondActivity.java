package com.example.nestedlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity implements ArrayAdapter.ItemClickListener, View.OnClickListener {
    Button bt;
    private final ArrayList<Cell> mylst = new ArrayList<>();
    ArrayAdapter adapter;
    String[] files = new String[20];
    Drawable[] drw = new Drawable[20];

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        bt = findViewById(R.id.bt);
        bt.setOnClickListener(this);

        // Прием выбранной позиции с предыдущей страницы
        Bundle arguments = getIntent().getExtras();
        int ind = arguments.getInt("pos");

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) RecyclerView recyclerView= findViewById(R.id.rv);// Связь разметки с кодом
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        copyAssets();

        setInitialData();
//         создаем адаптер

        adapter = new ArrayAdapter(this, mylst);
        adapter.setClickListener(this);
//        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
    }
//    Return
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(SecondActivity.this, MainActivity.class);
        this.startActivity(intent);
    }
    public void setInitialData() {
        mylst.add(new Cell(drw[0], "Саванна (ашера)"));
        mylst.add(new Cell(drw[1], "Эльф"));
        mylst.add(new Cell(drw[2], "Персидская"));
        mylst.add(new Cell(drw[3], "Русская голубая"));
        mylst.add(new Cell(drw[4], "Донской сфинкс"));
        mylst.add(new Cell(drw[5], "Сибирская"));
    }
    private void copyAssets() {
        AssetManager assetManager = getAssets();
        files = null;
        try {
            files = assetManager.list("Category/Cats/");
        } catch (IOException e) {
            Log.e("tag", "Failed to get asset file list.", e);
        }
        for (int i = 0; i < files.length; i++) {
            try {
                // get input stream
                InputStream ims = getAssets().open("Category/Cats/" + files[i]);
                // load image as Drawable
                Drawable d = Drawable.createFromStream(ims, null);
                drw[i] = d;
                ims.close();
            } catch (IOException ignored) {
            }
        }
    }

    @Override
    public void onItemClick(View view, int position) {
//        Toast.makeText(this, "Вы щелкнули по строке " + position,
//                Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(SecondActivity.this, ShowActivity.class);
        int pos = position;
        // pos – выбранная позиция, ее надо передать на вторую страницу
        intent.putExtra("pos", pos); // “pos” имя для передачи
//        intent.putExtra(databaseList(drw[pos]));
        this.startActivity(intent);
    }
}