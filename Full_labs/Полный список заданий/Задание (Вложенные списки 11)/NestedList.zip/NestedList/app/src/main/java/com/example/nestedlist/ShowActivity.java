package com.example.nestedlist;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

public class ShowActivity extends AppCompatActivity implements View.OnClickListener {
    String[] fname = {"ashera.png", "elf.png", "pers.png", "russblue.png", "sfinx.png", "sibir.png"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        ImageView img = findViewById(R.id.imageView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button btr = findViewById(R.id.btr);
        btr.setOnClickListener(this);
        // Прием выбранной позиции с предыдущей страницы
        Bundle arguments = getIntent().getExtras();
        int ind = arguments.getInt("pos");
        try
        {
            // Получение входного потока
            InputStream ims = getAssets().open("Category/Cats/" + fname[ind]);
            // load image as Drawable
            Drawable d = Drawable.createFromStream(ims, null);
            // Связать изображение с элементом на экране
            img.setImageDrawable(d);
            img.setScaleType(ImageView.ScaleType.FIT_XY);
            ims .close();
        }
        catch(IOException ignored)
        {
        }

    }

    @Override
    public void onClick(View v) {
        Intent intent = new Intent(ShowActivity.this, SecondActivity.class);
        this.startActivity(intent);
    }
}