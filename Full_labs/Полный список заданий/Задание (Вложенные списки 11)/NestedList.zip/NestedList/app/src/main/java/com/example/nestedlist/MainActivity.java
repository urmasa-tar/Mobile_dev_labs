package com.example.nestedlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ArrayAdapter.ItemClickListener {
    private final ArrayList<Cell> mylst = new ArrayList<>();
    com.example.nestedlist.ArrayAdapter adapter;
    String [] lst = {"Кошки", "Собаки", "Рыбы", "Насекомые"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) RecyclerView recyclerView= findViewById(R.id.rv);// Связь разметки с кодом
        recyclerView.setHasFixedSize(true);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        setInitialData();
//         создаем адаптер

        adapter = new ArrayAdapter(this, mylst);
        adapter.setClickListener(this);
//        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
    }
    @SuppressLint("UseCompatLoadingForDrawables")
    public void setInitialData() {
        mylst.add(new Cell(getDrawable(R.drawable.cat3), "Кошки"));
        mylst.add(new Cell(getDrawable(R.drawable.dog1), "Собаки"));
        mylst.add(new Cell(getDrawable(R.drawable.fish), "Рыбы"));
        mylst.add(new Cell(getDrawable(R.drawable.insect), "Насекомые"));
    }

    @Override
    public void onItemClick(View view, int position) {
        Intent intent = new Intent(MainActivity.this, SecondActivity.class);
        int pos = position;
        // pos – выбранная позиция, ее надо передать на вторую страницу
        intent.putExtra("pos", pos); // “pos” имя для передачи
        this.startActivity(intent);
    }
}